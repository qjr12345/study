<template>
  <div class="home" id="screen">
    <div class="top">
      <img class="topImg" src="../assets/顶部.png" alt="">
      <div class="title">社会培训管理可视化全景图</div>
      <div class="time">{{ this.time }}</div>
      <div class="right">
        <el-select v-model="value" placeholder="2022">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
    </div>
    <div class="content" style="display: flex;">
      <div style="width:468px">
        <div class="left">
          <div class="top">
            <div class="title">项目情况</div>
            <div class="title-a">单位：个</div>
            <div class="title-b flex" style="padding-top:73px;padding-bottom: 41px;">
              <div class="title-b-a">项目情况：</div>
              <div class="title-b-b">1</div>
              <div class="title-b-b">5</div>
              <div class="title-b-b">3</div>
              <div class="title-b-b">8</div>
            </div>
            <div class="content1">
              <div class="block blocka flex">
                <span class="demonstration">机械工程</span>
                <el-slider v-model="value1" disabled></el-slider>
                <div class="number">{{ value1 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">电器工程</span>
                <el-slider v-model="value2" disabled></el-slider>
                <div class="number">{{ value2 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">电器工程</span>
                <el-slider v-model="value3" disabled></el-slider>
                <div class="number">{{ value3 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">车辆工程</span>
                <el-slider v-model="value4" disabled></el-slider>
                <div class="number">{{ value4 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">车辆工程</span>
                <el-slider v-model="value5" disabled></el-slider>
                <div class="number">{{ value5 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">经济管理</span>
                <el-slider v-model="value6" disabled></el-slider>
                <div class="number">{{ value6 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">创意设计</span>
                <el-slider v-model="value7" disabled></el-slider>
                <div class="number">{{ value7 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">继续教育</span>
                <el-slider v-model="value8" disabled></el-slider>
                <div class="number">{{ value8 }}</div>
              </div>
              <div class="block blockb flex">
                <span class="demonstration">国际教育</span>
                <el-slider v-model="value9" disabled></el-slider>
                <div class="number">{{ value9 }}</div>
              </div>
            </div>
          </div>
          <div class="bottom">
            <div class="title">培训方式</div>
            <div class="content2 flex">
              <div class="nava flex">
                <img src="../assets/线上培训.png" alt="">
                <div class="nava-title">线上培训</div>
                <div class="numbernav">60个</div>
              </div>
              <div class="nava flex">
                <img src="../assets/线上培训.png" alt="">
                <div class="nava-title">线上培训</div>
                <div class="numbernav">60个</div>
              </div>
              <div class="nava flex">
                <img src="../assets/线上培训.png" alt="">
                <div class="nava-title">线上培训</div>
                <div class="numbernav">60个</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div class="middle" style="width: 862px;">
          <div class="top">
            <div class="title">培训人员情况</div>
            <div class="linea flex">
              <div class="linea-left">
                <div class="linea-left-a flex">
                  <img src="../assets/线上培训.png" alt="">
                  <div class="name">培训人次</div>
                  <div class="color">已达标</div>
                </div>
                <div class="linea-left-a linea-left-b flex">
                  <div class="lina-aa flex">
                    <div class="mb">目标：</div>
                    <div class="bigTitle">80</div>
                  </div>
                  <div class="lina-aa flex">
                    <div class="mb">实际：</div>
                    <div class="bigTitle bigTitleCo">80</div>
                  </div>
                </div>
              </div>
              <div class="linea-left">
                <div class="linea-left-a flex">
                  <img src="../assets/线上培训.png" alt="">
                  <div class="name">培训人日</div>
                  <div class="color colora">已达标</div>
                </div>
                <div class="linea-left-a linea-left-b flex">
                  <div class="lina-aa flex">
                    <div class="mb">目标：</div>
                    <div class="bigTitle">80</div>
                  </div>
                  <div class="lina-aa flex">
                    <div class="mb">实际：</div>
                    <div class="bigTitle bigTitleCo bigTitleCoa">80</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="lineb">
              <div class="lineb-a">各学院培训人员</div>
            </div>
            <div class="middlecharts" id="middlecharts" style="height:270px"></div>
          </div>
          <div class="aaa flex">
            <div class="bottom" style="position:relative">
              <div class="title">培训类型</div>
              <div id="content2" style="height:150px"></div>
              <div class="aaa-a" style="position:absolute;top:59%;left:41%;color: #fff;font-size: 14px;">
                <div style="color:#F1F1F1">培训总数：</div>
                <div style="font-size:18px">86</div>
              </div>

            </div>
            <div class="bottom">
              <div class="title">培训对象分布</div>
              <div id="content3" style="height:150px"></div>
            </div>
          </div>
        </div>
      </div>
      <div style="width:468px">
        <div class="right">
          <div class="top">
            <div class="title">资金概况</div>
            <div class="title-a">单位：万元</div>
            <div class="linea-left">
              <div class="linea-left-a flex">
                <img src="../assets/线上培训.png" alt="">
                <div class="name">资金情况</div>
                <div class="color">已达标</div>
              </div>
              <div class="linea-left-a linea-left-b flex">
                <div class="lina-aa flex">
                  <div class="mb">目标：</div>
                  <div class="bigTitle">80</div>
                </div>
                <div class="lina-aa flex">
                  <div class="mb">实际：</div>
                  <div class="bigTitle bigTitleCo">80</div>
                </div>
              </div>
            </div>

            <div class="line">
              <div class="line-title flex">
                <div class="center">序号</div>
                <div class="center">学院</div>
                <div class="center">已成交金额(万元)</div>
              </div>
              <div class="line-line flex">
                <div class="center">1</div>
                <div class="center">机械工程</div>
                <div class="center">900</div>
              </div>
              <div class="line-line flex">
                <div class="center">2</div>
                <div class="center">电气工程</div>
                <div class="center">870</div>
              </div>
              <div class="line-line flex">
                <div class="center">3</div>
                <div class="center">模具技术</div>
                <div class="center">500</div>
              </div>
              <div class="line-line flex">
                <div class="center">4</div>
                <div class="center">车辆工程</div>
                <div class="center">460</div>
              </div>
              <div class="line-line flex">
                <div class="center">5</div>
                <div class="center">信息工程</div>
                <div class="center">780</div>
              </div>
              <div class="line-line flex">
                <div class="center">6</div>
                <div class="center">经济管理</div>
                <div class="center">456</div>
              </div>
              <div class="line-line flex">
                <div class="center">7</div>
                <div class="center">创意设计</div>
                <div class="center">322</div>
              </div>
            </div>
          </div>
          <div class="bottom">
            <div class="title">资金来源</div>

            <div class="middlecharts1" id="middlecharts1" style="height:230px"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
import * as echarts from 'echarts';
export default {
  name: 'HomeView',
  data() {
    return {
      time: '',
      options: [{
        value: '选项1',
        label: '2022年'
      }, {
        value: '选项2',
        label: '2023年'
      }, {
        value: '选项3',
        label: '2024年'
      }, {
        value: '选项4',
        label: '2025年'
      }, {
        value: '选项5',
        label: '2026年'
      }],
      value: '',
      value1: 50,
      value2: 40,
      value3: 60,
      value4: 30,
      value5: 70,
      value6: 30,
      value7: 20,
      value8: 50,
      value9: 80,
    }
  },
  mounted() {
    this.initView()
    this.initView1()
    this.initView2()
    this.initView3()
    // this.initView4()

    this.handleScreenAuto();

    window.onresize = () => this.handleScreenAuto();


    setInterval(() => {
      this.time = this.howtime()
    }, 1000)
  },
  methods: {
    handleScreenAuto() {
      const designDraftWidth = 1920;//设计稿的宽度
      const designDraftHeight = 1080;//设计稿的高度
      //根据屏幕的变化适配的比例
      const scale = document.documentElement.clientWidth / document.documentElement.clientHeight < designDraftWidth / designDraftHeight ?
        (document.documentElement.clientWidth / designDraftWidth) :
        (document.documentElement.clientHeight / designDraftHeight);
      //缩放比例
      (document.querySelector('#screen')).style.transform = `scale(${scale}) translate(-50%)`;
    },

    howtime() {
      var nowdate = new Date();
      var year = nowdate.getFullYear(),
        month = nowdate.getMonth() + 1,
        date = nowdate.getDate(),
        day = nowdate.getDay(),
        week = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"],
        h = nowdate.getHours(),
        m = nowdate.getMinutes(),
        s = nowdate.getSeconds(),
        h = this.checkTime(h),
        m = this.checkTime(m),
        s = this.checkTime(s);
      return year + "-" + month + "-" + date + " " + h + ":" + m + ":" + s;
    },
    checkTime(i) {
      if (i < 10) {
        i = "0" + i;
      }
      return i;
    },
    initView() {
      var chartDom = document.getElementById('middlecharts');
      var myChart = echarts.init(chartDom);
      var option;

      option = {
        xAxis: {
          type: 'category',
          data: ['机械工程', '电气工程', '模具技术', '车辆工程', '信息工程', '经济管理', '创意设计', '继续教育', '国际教育']
        },
        grid: {
          x: 50,
          y: 50,
          x2: 50,
          y2: 40
        },
        yAxis: {
          type: 'value'
        },
        series: [

          {
            data: [120, 200, 150, 80, 70, 110, 130, 60, 80],
            type: 'bar',
            showBackground: true,
            backgroundStyle: {
              color: 'rgba(180, 180, 180, 0.2)',
            },
            barWidth: '30%',
            itemStyle: {
              //通常情况下：
              normal: {
                // barBorderRadius: 8,
                //每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                color: function(params) {
                  var colorList = [
                    ['#0489F0', '#28D8E8'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#94225F', '#FA82C2'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#209CFF', '#68E0CF'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#D4478B', '#EC7BB2'],
                    ['#209CFF', '#68E0CF'],
                    ['#159A47', '#43CF77'],
                  ];
                  var index = params.dataIndex;
                  if (params.dataIndex >= colorList.length) {
                    index = params.dataIndex - colorList.length;
                  }
                  return new echarts.graphic.LinearGradient(0, 1, 0, 0,
                    [{
                      offset: 0,
                      color: colorList[index][0]
                    },
                    {
                      offset: 1,
                      color: colorList[index][1]
                    }
                    ]);
                }
              },
            },
          }
        ]
      };

      option && myChart.setOption(option);
    },
    initView1() {
      var chartDom = document.getElementById('content3');
      var myChart = echarts.init(chartDom);
      var option;

      option = {
        legend: {
          top: 'bottom'
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            restore: { show: true },
            saveAsImage: { show: true }
          }
        },
        legend: {
          show: false,
          orient: 'vertical',
          left: 'right',

        },
        series: [
          {
            name: 'Nightingale Chart',
            type: 'pie',
            radius: [30, 45],
            center: ['45%', '50%'],
            roseType: 'area',
            itemStyle: {
              borderRadius: 8
            },
            data: [
              { value: 580, name: '新型职业农民 30%' },
              { value: 580, name: '下岗人员 30%' },
              { value: 648, name: '退役士兵 40%' },

            ]
          }
        ]
      };

      option && myChart.setOption(option);
    },
    initView2() {
      // var chartDom = document.getElementById('content2');
      // var colors = ['#FDD100', '#08CED0', '#7351E3', '#FF4873', '#01BE6E']
      // 颜色下标，每次渲染饼图一个扇区加一操作
      // var i = 0
      var echertID = echarts.init(document.getElementById('content2'))
      echertID.setOption({
        title: {
          text: '',
          left: 'left',
          textStyle: {
            'fontSize': 20,
            'fontWeight': '500',
            'color': '#fff'
          }
        },

        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}:{c}({d}%)'
        },
        legend: {
          right: 'right',
          // left:10,
          // orient:"horizontal",
          top: 'center',
          padding: 20,
          // bottom: 10,
          data: ['社会培训:45%', '校内培训:25%', '涉外培训:15%', '社区教育:20%'],
          itemWidth: 24, // 设置宽度
          itemHeight: 14, // 设置高度
          itemGap: 5, // 设置间距
          textStyle: {
            // 文字颜色
            color: '#fff',
            // 字体粗细 'normal','bold','bolder','lighter',100 | 200 | 300 | 400...
            fontWeight: '400',
            // 字体系列
            fontFamily: 'Source Han Sans CN',
            // 字体大小
            fontSize: 12
          }
        },
        series: [
          {
            name: '占比：',
            type: 'pie',
            radius: [35, 65], // 饼图的大小
            labelLine: {// 图形外文字线
              normal: {
                length: 5,
                length2: 80,
                lineStyle: {
                  color: '#28B1C7'
                }
              }
            },
            center: ['50%', '50%'],
            roseType: 'area', // 饼图的样式
            label: { // 线上文字的样式
              normal: {
                formatter: '{b|{b}}{c|{c}}\n\n', // 线上文字
                show: false,

                borderWidth: 20,
                borderRadius: 4,
                // shadowBlur:3,
                // shadowOffsetX: 2,
                // shadowOffsetY: 2,
                // shadowColor: '#999',
                padding: [0, -80],
                rich: {
                  a: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  b: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  c: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  d: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  }
                  // abg: {
                  //     backgroundColor: '#333',
                  //     width: '100%',
                  //     align: 'right',
                  //     height: 22,
                  //     borderRadius: [4, 4, 0, 0]
                  // },
                  /*  hr: {
                    borderColor: '#333',
                    width: '100%',
                    borderWidth: 0.5,
                    height: 0
                  }, */
                  // per: {
                  //   color: '#333',
                  //   padding: [2, 4],
                  //   borderRadius: 2
                  // }
                }
              }
            },
            data: [
              {
                value: 5,
                name: '社会培训:45%',
                itemStyle: {
                  normal: {
                    color: '#19ACF9'
                  }
                }
              },
              {
                value: 5,
                name: '校内培训:25%',
                itemStyle: {
                  normal: {
                    color: '#E4951E'
                  }
                }
              },
              {
                value: 6,
                name: '涉外培训:15%',
                itemStyle: {
                  normal: {
                    color: '#0491FA'
                  }
                }
              },
              {
                value: 10,
                name: '社区教育:20%',
                itemStyle: {
                  normal: {
                    color: '#029790'
                  }
                }
              },

            ],
            itemStyle: {
              // normal: {
              //   // 设置饼图的颜色
              //   color: function() {
              //     return colors[i++]
              //   }
              // },
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      })
      setTimeout(function() {
        window.addEventListener('resize', function() {
          echertID.resize()
        })
      }, 50)

    },
    initView3() {
      var chartDom = document.getElementById('middlecharts1');
      var myChart = echarts.init(chartDom);
      var option;

      option = {
        xAxis: {
          type: 'category',
          data: ['涉外项目', '学生个体', '公益培训', '社会个体', '政府补贴', '行业委托']
        },
        grid: {
          x: 50,
          y: 70,
          x2: 50,
          y2: 40
        },
        yAxis: {
          type: 'value'
        },
        series: [

          {
            data: [120, 200, 150, 80, 70, 110,],
            type: 'bar',
            showBackground: true,
            backgroundStyle: {
              color: 'rgba(180, 180, 180, 0.2)',
            },
            barWidth: '30%',
            itemStyle: {
              //通常情况下：
              normal: {
                // barBorderRadius: 8,
                //每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                color: function(params) {
                  var colorList = [
                    ['#0489F0', '#28D8E8'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#94225F', '#FA82C2'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#209CFF', '#68E0CF'],
                    ['#FF5A1F', '#FFC31F'],
                    ['#D4478B', '#EC7BB2'],
                    ['#209CFF', '#68E0CF'],
                    ['#159A47', '#43CF77'],
                  ];
                  var index = params.dataIndex;
                  if (params.dataIndex >= colorList.length) {
                    index = params.dataIndex - colorList.length;
                  }
                  return new echarts.graphic.LinearGradient(0, 1, 0, 0,
                    [{
                      offset: 0,
                      color: colorList[index][0]
                    },
                    {
                      offset: 1,
                      color: colorList[index][1]
                    }
                    ]);
                }
              },
            },
          }
        ]
      };

      option && myChart.setOption(option);
    },
    echartFun() {
      // var colors = ['#FDD100', '#08CED0', '#7351E3', '#FF4873', '#01BE6E']
      // 颜色下标，每次渲染饼图一个扇区加一操作
      // var i = 0
      var echertID = echarts.init(document.getElementById('content3'))
      echertID.setOption({
        title: {
          text: '废气因子占比',
          left: 'left',
          textStyle: {
            'fontSize': 20,
            'fontWeight': '500',
            'color': '#fff'
          }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}:{c}({d}%)'
        },
        legend: {
          left: 'left',
          top: 'bottom',
          // bottom: 10,
          data: ['非甲烷总烃', 'PM2.5', 'PM10', '颗粒物', '油烟浓度'],
          itemWidth: 24, // 设置宽度
          itemHeight: 14, // 设置高度
          itemGap: 5, // 设置间距
          textStyle: {
            // 文字颜色
            color: '#fff',
            // 字体粗细 'normal','bold','bolder','lighter',100 | 200 | 300 | 400...
            fontWeight: '400',
            // 字体系列
            fontFamily: 'Source Han Sans CN',
            // 字体大小
            fontSize: 12
          }
        },
        series: [
          {
            name: '占比：',
            type: 'pie',
            radius: [15, 75], // 饼图的大小
            labelLine: {// 图形外文字线
              normal: {
                length: 5,
                length2: 80,
                lineStyle: {
                  color: '#28B1C7'
                }
              }
            },
            center: ['50%', '50%'],
            roseType: 'area', // 饼图的样式
            label: { // 线上文字的样式
              normal: {
                formatter: '{b|{b}}{c|{c}}\n\n', // 线上文字
                borderWidth: 20,
                borderRadius: 4,
                // shadowBlur:3,
                // shadowOffsetX: 2,
                // shadowOffsetY: 2,
                // shadowColor: '#999',
                padding: [0, -80],
                rich: {
                  a: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  b: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  c: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  },
                  d: {
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: 20
                  }
                  // abg: {
                  //     backgroundColor: '#333',
                  //     width: '100%',
                  //     align: 'right',
                  //     height: 22,
                  //     borderRadius: [4, 4, 0, 0]
                  // },
                  /*  hr: {
                    borderColor: '#333',
                    width: '100%',
                    borderWidth: 0.5,
                    height: 0
                  }, */
                  // per: {
                  //   color: '#333',
                  //   padding: [2, 4],
                  //   borderRadius: 2
                  // }
                }
              }
            },
            data: [
              {
                value: 10,
                name: '非甲烷总烃',
                itemStyle: {
                  normal: {
                    color: '#FDD100'
                  }
                }
              },
              {
                value: 5,
                name: 'PM2.5',
                itemStyle: {
                  normal: {
                    color: '#08CED0'
                  }
                }
              },
              {
                value: 15,
                name: 'PM10',
                itemStyle: {
                  normal: {
                    color: '#7351E3'
                  }
                }
              },
              {
                value: 25,
                name: '颗粒物',
                itemStyle: {
                  normal: {
                    color: '#FF4873'
                  }
                }
              },
              {
                value: 20,
                name: '油烟浓度',
                itemStyle: {
                  normal: {
                    color: '#01BE6E'
                  }
                }
              }
            ],
            itemStyle: {
              // normal: {
              //   // 设置饼图的颜色
              //   color: function() {
              //     return colors[i++]
              //   }
              // },
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      })
      setTimeout(function() {
        window.addEventListener('resize', function() {
          echertID.resize()
        })
      }, 50)
    },
  }
}
</script>
<style lang="scss" scoped>
* {
  padding: 0;
  margin: 0;
}

.flex {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.home {
  background-image: url("@/assets/bg.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  display: inline-block;
  width: 1920px; //设计稿的宽度
  height: 1080px; //设计稿的高度
  transform-origin: 0 0;
  position: absolute;
  left: 50%;
  overflow: hidden;
}

.top {
  position: relative;

  .topImg {
    width: 100%;
    height: 100%;
  }

  .title {
    position: absolute;
    left: 0;
    top: 8px;
    right: 0;
    font-size: 36px;
    font-family: FZZhengHeiS-R-GB;
    font-weight: 400;
    color: #DBEFFF;
  }

  .time {
    font-size: 18px;
    font-weight: 400;
    color: #FFFFFF;
    position: absolute;
    left: 20px;
    top: 60px;
  }

  .right {
    position: absolute;
    right: 20px;
    top: 60px;
    background-image: url("../assets/培训人次.png");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
  }

  ::v-deep .el-input__inner {
    background: transparent !important;
    border: none;
    width: 75px;
    font-size: 12px;
    height: 25px;
  }

  ::v-deep .el-select__caret {
    margin-top: 5px;
  }

}

.content {
  width: 100%;
  // height: 100%;
  padding: 20px;
  box-sizing: border-box;

  .left {
    // background-color: red;
    width: 100%;
    height: 100%;
    height: 500px;

    .top {
      background-image: url("../assets/项目情况.png");
      background-repeat: no-repeat;
      background-size: 100% 100%;
      // height: 400px;
      color: #fff;
      position: relative;

      height: 617px;

      .title {
        position: absolute;
        left: 0;
        right: 0;
        font-size: 18px;
        top: 4px;
        font-weight: 500;
        color: #EAEFF2;
      }

      .title-a {
        position: absolute;
        right: 20px;
        top: 20px;
        font-size: 14px;
      }

      .title-b {
        justify-content: center;
      }

      .title-b-b {
        width: 28px;
        height: 36px;
        line-height: 36px;
        background: linear-gradient(0deg, #06296A, rgba(6, 41, 106, 0));
        border: 1px solid;
        border-image: linear-gradient(0deg, rgba(0, 182, 255, 0.8), rgba(0, 182, 255, 0.8)) 1 1;
        margin: 0 5px;
        font-size: 36px;
        font-weight: bold;
        color: #00FDF6;
      }
    }

    .content1 {
      width: 90%;
      margin-left: 20px;

      .demonstration {
        margin-right: 20px;
        font-size: 14px;
        color: #ADE6FA;
      }

      .number {
        font-size: 14px;
        color: #ADE6FA;
        margin-left: 5px;
      }

      ::v-deep .el-slider {
        width: 55%;
      }

      .block {
        height: 33px;
        margin-bottom: 15px;
      }

      .blocka {
        ::v-deep .el-slider__bar {
          background-color: #FEB019;
        }
      }

      .blockb {
        ::v-deep .el-slider__bar {
          background-color: #1D90E9;
        }
      }

      ::v-deep .el-slider__button {
        display: none;
      }
    }


    .bottom {
      background-image: url("../assets/培训方式bg.png");
      background-repeat: no-repeat;
      background-size: 100% 100%;
      height: 299px;
      position: relative;
      background-position: center;

      .title {
        position: absolute;
        left: 30px;
        top: 50px;
        font-size: 18px;
        font-family: Source Han Sans CN;
        font-weight: bold;
        color: #F1F1F1;
      }

      .content2 {
        .nava {
          flex-direction: column;
          padding-top: 60px;

          img {
            width: 50%;
          }

          .nava-title {
            margin: 15px 0;
          }

          .nava-title,
          .numbernav {
            font-size: 18px;
            font-weight: 400;
            color: #F3FFFF;
          }
        }
      }
    }

  }

  .middle {
    .top {
      background-image: url("../assets/培训人员情况.png");
      background-repeat: no-repeat;
      background-size: 100% 100%;
      height: 617px;
      background-position: center;

      .title {
        font-size: 20px;
        font-weight: 500;
        color: #EAEFF2;
      }

      .linea {
        width: 100%;
        padding: 0 40px;
        box-sizing: border-box;

        .linea-left {
          width: 49%;
          margin-top: 45px;
          background: url("../assets/培训人次.png") no-repeat 100% 100%;
          // height: 50px;
          padding-top: 10px;
          background-position: center;

          .linea-left-a {
            justify-content: center;

            img {
              width: 30px;
              height: 30px;
            }

            .name {
              font-size: 20px;
              font-weight: 500;
              color: #FEFEFE;
              margin: 0 10px;
            }

            .color {
              background-color: #09AC46;
              border-radius: 10px 10px 10px 0px;
              font-size: 12px;
              font-weight: 500;
              color: #FEFEFE;
              padding: 3px;
              margin-bottom: 10px;
            }

            .colora {
              background: #DA0258;
            }
          }

          .linea-left-b {
            justify-content: space-between;
            width: 100%;
            text-align: center !important;

          }

          .lina-aa {
            width: 50%;
            border-right: 1px solid #304A92;
            font-size: 16px;
            font-weight: 500;
            color: #BCE4FF;
            justify-content: center;
            margin: 10px 0;

            div {
              text-align: center;
            }

            .bigTitle {
              font-size: 34px;
              color: #fff;
              font-weight: bold;
            }

            .bigTitleCo {
              color: #1CCC5E;
            }

            .bigTitleCoa {
              color: #F12A59;
            }
          }
        }
      }

      .lineb {
        margin: 20px 0;
        margin-top: 5px;
        background: url("../assets/各学院培训人员title.png") no-repeat 50% 50%;
        font-size: 20px;
        font-weight: 400;
        color: #38E3FF;
        background-position: center;
      }

      .middlecharts {
        margin-top: -60px;
      }

    }

    .bottom {
      width: 50%;
      background-image: url("../assets/培训方式bg.png");
      background-repeat: no-repeat;
      background-size: 100% 100%;
      height: 299px;
      position: relative;
      background-position: center;

      .title {
        position: absolute;
        left: 30px;
        top: 50px;
        font-size: 18px;
        font-family: Source Han Sans CN;
        font-weight: bold;
        color: #F1F1F1;
      }

      .content2 {
        .nava {
          flex-direction: column;
          padding-top: 60px;

          img {
            width: 50%;
          }

          .nava-title {
            margin: 15px 0;
          }

          .nava-title,
          .numbernav {
            font-size: 18px;
            font-weight: 400;
            color: #F3FFFF;
          }
        }
      }

      #content2 {
        margin-top: 60px;
      }

      #content3 {
        margin-top: 60px;
      }
    }

  }

  .right {
    .top {
      background-image: url("../assets/项目情况.png");
      background-repeat: no-repeat;
      background-size: 100% 100%;
      // height: 400px;
      color: #fff;
      position: relative;
      height: 617px;

      .title {
        position: absolute;
        left: 0;
        right: 0;
        font-size: 18px;
        top: 4px;
        font-weight: 500;
        color: #EAEFF2;
      }

      .title-a {
        position: absolute;
        right: 20px;
        top: 20px;
        font-size: 14px;
      }

      .title-b {
        justify-content: center;
      }

      .title-b-b {
        width: 28px;
        height: 36px;
        line-height: 36px;
        background: linear-gradient(0deg, #06296A, rgba(6, 41, 106, 0));
        border: 1px solid;
        border-image: linear-gradient(0deg, rgba(0, 182, 255, 0.8), rgba(0, 182, 255, 0.8)) 1 1;
        margin: 0 5px;
      }
    }

    .linea-left {
      width: 90%;
      margin-left: 5%;
      margin-top: -7px;
      background: url("../assets/培训人次.png") no-repeat 100% 100%;
      // height: 50px;
      padding-top: 10px;

      .linea-left-a {
        justify-content: center;

        img {
          width: 30px;
          height: 30px;
        }

        .name {
          font-size: 20px;
          font-weight: 500;
          color: #FEFEFE;
          margin: 0 10px;
        }

        .color {
          background-color: #09AC46;
          border-radius: 10px 10px 10px 0px;
          font-size: 12px;
          font-weight: 500;
          color: #FEFEFE;
          padding: 3px;
          margin-bottom: 10px;
        }

        .colora {
          background: #DA0258;
        }
      }

      .linea-left-b {
        justify-content: space-between;
        width: 100%;
        text-align: center !important;

      }

      .lina-aa {
        width: 100%;
        border-right: 1px solid #304A92;
        font-size: 16px;
        font-weight: 500;
        color: #BCE4FF;
        justify-content: center;
        margin: 10px 0;

        div {
          text-align: center;
        }

        .bigTitle {
          font-size: 34px;
          color: #fff;
          font-weight: bold;
        }

        .bigTitleCo {
          color: #1CCC5E;
        }

        .bigTitleCoa {
          color: #F12A59;
        }
      }
    }

    .line {
      margin-top: 20px;
      padding: 0 20px;

      .line-title {
        background-color: #194099;
        padding: 5px 10px;

        div {
          width: 33%;
          font-size: 13px;
          text-align: center;
          color: #0CF3FB;
        }
      }

      .line-line {
        padding: 5px 0;
        border-bottom: 1px dashed #fff;

        div {
          width: 33%;
          font-size: 13px;
          text-align: center;

        }
      }
    }

    .bottom {
      background-image: url("../assets/培训方式bg.png");
      background-repeat: no-repeat;

      height: 299px;
      position: relative;
      background-position: center;

      .title {
        position: absolute;
        left: 30px;
        top: 50px;
        font-size: 18px;
        font-family: Source Han Sans CN;
        font-weight: bold;
        color: #F1F1F1;
      }

      .content2 {
        .nava {
          flex-direction: column;
          padding-top: 60px;

          img {
            width: 50%;
          }

          .nava-title {
            margin: 15px 0;
          }

          .nava-title,
          .numbernav {
            font-size: 18px;
            font-weight: 400;
            color: #F3FFFF;
          }
        }
      }
    }
  }


}
</style>
